package com.example.aurtisticsv.models;

public class ModelChatlist {
    String id;

    public ModelChatlist(String id) {
        this.id = id;
    }

    public String getId() {
        return this.id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
