package com.example.aurtisticsv.notifications;

public class Response {
    private String success;
}
